import cx_Freeze
import sys, pkgutil

base = None
packages = ['module_email', 'win32com', 'win32api', 'selenium', 'sys', 'getpass', 'time', 'wget', 'PyQt5', 
            "re", "shutil", "zipfile", "ctypes", "collections", "encodings", "importlib", "logging",
            'urllib', 'urllib3', 'http', 'html', 'ipaddress', 'certifi', 'json', 'xml', 'asyncio', 'concurrent',
            'extract_msg', 'bs4', 'tzlocal', 'backports', 'zoneinfo', 'compressed_rtf', 'RTFDE', 'lark',
            'oletools', 'ebcdic', 'atexit', 'signal', 'sys', 'tzdata']

if sys.platform == 'win32':
    base = 'Win32GUI'

executables = [cx_Freeze.Executable('main.py', base=base, icon='icons\\icon.ico')]

def ap():
    return [i.name for i in list(pkgutil.iter_modules()) if i.ispkg]

def nf(a, v):
    try:
        a.index(v)
        return False
    except:
        return True

cx_Freeze.setup(
    py_modules=[],
    name = 'Email and Documentation Tool',
    options = {
        'build_exe': {
            'packages': packages,
            'zip_include_packages': [
                
            ],
            'excludes': [
                i for i in ap() if nf(packages, i)
            ],
            'build_exe': 'EmailDocuTool v1.5',
            'optimize': 2
        }
    },
    version = '1.5',
    description = '',
    executables = executables
)