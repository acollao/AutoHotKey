import requests
import os

def download_file(url, save_folder):
    os.makedirs(save_folder, exist_ok=True)

    filename = url.split("/")[-1]
    file_path = os.path.join(save_folder, filename)

    with requests.get(url, stream=True, verify=False) as r:
        r.raise_for_status()

        with open(file_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)

    return file_path


#documents_folder = os.path.expanduser(f"~\Documents")

#file_path = download_file(
#    "https://msedgedriver.microsoft.com/151.0.4129.59/edgedriver_win64.zip",
#    os.path.join(documents_folder, "Selenium")
#)

#print(file_path)