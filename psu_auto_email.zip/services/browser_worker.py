from PyQt5.QtCore import QObject
from PyQt5.QtCore import pyqtSignal
from PyQt5.QtCore import pyqtSlot
from automation.selenium_service import SeleniumService
import pythoncom

class BrowserWorker(QObject):

    finished = pyqtSignal(object)

    error = pyqtSignal(str)

    log = pyqtSignal(str)

    def __init__(self):

        super().__init__()

        self.browser = SeleniumService()

    @pyqtSlot(str, dict)
    def execute(self, action, params):

        try:
            pythoncom.CoInitialize()
            
            self.log.emit(
                f"Executing {action}"
            )

            if action == "connect":

                result = self.browser.connect2web()

            elif action == "search_claim":

                result = self.browser.document_claim(
                    params
                )

            elif action == "close":

                result = self.browser.close_browser()

            else:

                raise Exception(
                    f"Unknown action: {action}"
                )

            self.finished.emit(result)

        except Exception as e:

            self.error.emit(str(e))