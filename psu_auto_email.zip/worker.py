from PyQt5.QtCore import QObject, QRunnable, pyqtSignal, pyqtSlot
import pythoncom

class WorkerSignals(QObject):
    finished = pyqtSignal(object)
    error = pyqtSignal(str)

class Worker(QRunnable):

    def __init__(self, fn, *args, **kwargs):
        super().__init__()

        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.signals = WorkerSignals()

    @pyqtSlot()
    def run(self):

        pythoncom.CoInitialize()
        
        try:
            result = self.fn(
                *self.args,
                **self.kwargs
            )

            self.signals.finished.emit(result)

        except Exception as e:
            self.signals.error.emit(str(e))