from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
# from selenium.webdriver.common.keys import Keys
from PyQt5.QtWidgets import *
from PyQt5 import uic
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from time import sleep
from sys import argv
from getpass import getuser
from win32com.client import Dispatch
from wget import download
from shutil import rmtree
from zipfile import ZipFile
from datetime import datetime, timedelta
import module_email
import os, ctypes, atexit, signal, sys
import helper
from worker import Worker
from services.browser_worker import BrowserWorker
from PyQt5.QtWidgets import QMessageBox

class UI(QMainWindow):

    browser_request = pyqtSignal(
        str,
        dict
    )

    def __init__(self):
        super(UI, self).__init__()

        self.setup_browser_worker()
        #self.load_events()

        self.browser_request.connect(
            self.browser_worker.execute
        )

        self.threadpool = QThreadPool()
        uic.loadUi("ui\\main.ui", self)

        self.browser_thread.start()
        self.toolButton_email = self.findChild(QToolButton, "btn_email")
        self.toolButton_documentation = self.findChild(QToolButton, "btn_documentation")
        # self.toolButton_medical = self.findChild(QToolButton, "toolButton_medical")
        self.toolButton_connect2web = self.findChild(QToolButton, "btn_connect2web")
        self.lineEdit_control = self.findChild(QLineEdit, "lineEdit_control_2") # Claim Number
        self.lineEdit_dos1 = self.findChild(QLineEdit, "lineEdit_control_3") # DOS Date 1
        self.lineEdit_dos2 = self.findChild(QLineEdit, "lineEdit_control_4") # DOS Date 2
        self.stackedWidget = self.findChild(QStackedWidget, "stackedWidget")
        self.comboBox_email_templates = self.findChild(QComboBox, "comboBox_email_templates_2")
        self.textEdit_preview = self.findChild(QTextEdit, "textEdit_preview_2")
        self.textEdit_docu_preview = self.findChild(QTextEdit, "textEdit_docu_preview_2")
        self.pushButton_create_email = self.findChild(QPushButton, "pushButton_create_email_2")
        self.sent_emails = self.findChild(QListWidget, "listWidget")
        self.statusbar = self.findChild(QStatusBar, "statusbar")
        self.statusbar.showMessage("Application Ready")
        self.lineEdit_claimId = self.findChild(QLineEdit, "lineEdit_claimId")
        self.lineEdit_control_docu = self.findChild(QLineEdit, "lineEdit_claimId_2")
        self.textEdit_emailPreview = self.findChild(QTextEdit, "textEdit_emailPreview")
        self.pushButton_docSubmit = self.findChild(QPushButton, "pushButton_docSubmit")

        # Design
        # self.toolButton_email.setAutoRaise(True)
        # self.toolButton_documentation.setAutoRaise(True)
        # self.toolButton_medical.setAutoRaise(True)
        # self.toolButton_connect2web.setAutoRaise(True)

        # Variables
        self.driver = None
        self.gcn_driver = None
        self.claim_num = ''
        self.provider_name = ''
        self.from_date = ''
        self.through_date = ''
        self.strata_result = ''
        self.jurisdiction = ''
        self.text_arr = []
        self.sent_obj = []

        self.wnd1 = ""
        self.wnd2 = ""
        self.wnd3 = ""

        self.email_body = ""
        self.recipients = ""
        self.cc = ""
        self.subject = ""

        # Functions
        self.toolButton_email.clicked.connect(self.page_email)
        self.toolButton_documentation.clicked.connect(self.page_docu)
        self.toolButton_connect2web.clicked.connect(self.connect2web)
        self.comboBox_email_templates.currentIndexChanged.connect(self.show_email_content)
        self.pushButton_create_email.clicked.connect(self.create_email)
        self.pushButton_docSubmit.clicked.connect(self.document_claim)
        self.sent_emails.itemClicked.connect(self.email_select)

        atexit.register(self.exit_cleanup)
        signal.signal(signal.SIGTERM, self.exit_cleanup)
        signal.signal(signal.SIGINT, self.exit_cleanup)
        sys.excepthook = self.excepthook_handler

        # Show The App
        self.setWindowTitle('PSU Email/Documentation Tool')
        # self.showMaximized()
        self.setWindowIcon(QIcon('icons\\icon.ico'))
        # Fetch current flags and clear the Maximize Button Hint
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowMaximizeButtonHint)
        self.show()

    def set_status(self, message):
        self.statusbar.showMessage(message)

    def browser_completed(self, result):
        self.set_status(
            "Connected"
        )
        print(result)

    def browser_error(self, message):

        QMessageBox.critical(
            self,
            "Error",
            message
        )

    def browser_log(self):
        return 0
    
    def setup_browser_worker(self):
    
        self.browser_thread = QThread()

        self.browser_worker = BrowserWorker()

        self.browser_worker.moveToThread(
            self.browser_thread
        )

        self.browser_worker.finished.connect(
            self.browser_completed
        )

        self.browser_worker.error.connect(
            self.browser_error
        )

        self.browser_worker.log.connect(
            self.browser_log
        )

        self.browser_thread.start()

    def exit_cleanup(self):
        try:
            self.driver.close()
            self.driver.quit()
        except:
            return

    def excepthook_handler(self, type, value, trace):
        dt = datetime.datetime.now()
        with open("error.log", "a") as log:
            log.write(f"{dt}\n{type}\n{value}\n{trace}\n----------\n")

    def page_email(self):
        templates = module_email.email_templates()
        if not self.comboBox_email_templates.count() > 0:
            self.comboBox_email_templates.addItems(templates)

        # self.toolButton_email.setStyleSheet("background-color:rgb(117, 113, 113); color:rgb(201, 201, 201);")
        # self.toolButton_documentation.setStyleSheet("background-color:rgb(255, 209, 3); color:rgb(97, 98, 101);")
        self.stackedWidget.setCurrentIndex(1)

    def page_docu(self):
        self.stackedWidget.setCurrentIndex(2)

        outlook = Dispatch("Outlook.Application")
        mapi = outlook.GetNameSpace("MAPI")

        sent_folder = mapi.GetDefaultFolder(5)
        sent_items = sent_folder.Items
        try:
            print("5")

            start_date = (
                datetime.now() - timedelta(days=2)
            ).strftime("%m/%d/%Y %I:%M %p")

            print("6", start_date)

        except Exception as e:
            print("ERROR:", str(e))

        filtered_items = sent_items.Restrict(
            f"[SentOn] >= '{start_date}'"
        )
        filtered_items.Sort("[SentOn]", True)

        self.sent_emails.clear()
        for msg in filtered_items:
            try:
                self.sent_emails.addItem(msg.Subject)
            except Exception:
                pass

    def email_select(self, item):
        outlook = Dispatch("Outlook.Application")
        mapi = outlook.GetNameSpace("MAPI")

        sent_items = mapi.GetDefaultFolder(5)

        recip_address = ""
        cc_address = ""
        email_body = ""

        for msg in sent_items.Items:
            if item.text() == msg.Subject:
                email_body = msg.Body.strip().replace("\r\n", "<br/>")
                email_body = email_body.replace("<br/><br/>", "\n")
                email_body = email_body.replace("<br/>", "\n")

                for recip in msg.Recipients:
                    try:
                        if recip.Type == 2:
                            cc_address = f"{cc_address}; {recip.Name} {recip.AddressEntry.GetExchangeUser().PrimarySmtpAddress}"
                        else:
                            recip_address = f"{recip_address}; {recip.Name} {recip.AddressEntry.GetExchangeUser().PrimarySmtpAddress}"
                    except:
                        if recip.Type == 2:
                            cc_address = f"{cc_address}; {recip.Name} {recip.Address}"
                        else:
                            recip_address = f"{recip_address}; {recip.Name} {recip.Address}"
                
                tmp_text = f"From: {msg.Sender} {msg.Sender.GetExchangeUser().PrimarySmtpAddress if msg.SenderEmailType == 'EX' else msg.Sender.SenderEmailAddress}"
                tmp_text = f"{tmp_text}\nSent: {msg.SentOn.strftime('%A, %B %d, %Y %I:%M:%S %p')}\nTo: {recip_address[2:]}"
                if not cc_address == "": tmp_text = f"{tmp_text}\nCC: {cc_address[2:]}\nSubject: {msg.Subject}"

                self.textEdit_emailPreview.setText(f"{tmp_text}\n\n{email_body}")
                break

    def show_email_content(self):
        template = self.comboBox_email_templates.currentText()
        if not template == "":
            content = module_email.email_content(template)
            body = content[0]
            if isinstance(body, bytes):
                body = body.decode('utf-8')
            self.textEdit_preview.setHtml(body)
            self.email_body = body
            self.recipients = content[1]
            self.cc = content[2]
            self.subject = content[3]

        if not self.comboBox_email_templates.currentText() == "":
            self.get_info()

    def create_email(self):
        self.email_body = self.textEdit_preview.toHtml()
        args = [self.comboBox_email_templates.currentText(), self.email_body, self.recipients, self.cc, self.subject, self.jurisdiction, self.claim_num]
        module_email.create_email(args)

    def popup(self, msg):
        font = QFont('Arial', 10)
        self.msgbox = QMessageBox()
        self.msgbox.setFont(font)
        self.msgbox.setWindowTitle('PSU - Email Automation')
        self.msgbox.setText(msg)
        self.msgbox.setStandardButtons(QMessageBox.Ok)
        self.msgbox.adjustSize()
        self.msgbox.exec_()

    def popup_question(self, msg):
        font = QFont('Arial', 10)
        msgbox = QMessageBox()
        msgbox.setFont(font)
        msgbox.setWindowTitle('PIP Invoices')
        msgbox.setText(msg)
        msgbox.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msgbox.setDefaultButton(QMessageBox.No)
        msgbox.adjustSize()
        result = msgbox.exec_()
        if result == QMessageBox.Yes:
            return True
        else:
            return False

    def is_driver_connected(self):
        if self.driver is not None:
            try:
                self.driver.current_url
                return True
            except WebDriverException:
                return False
        else:
            return False
        
    def update_edge_browser(self, folder_path):
        fso = Dispatch("Scripting.FileSystemObject")
        version = fso.GetFileVersion("c:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe")
        url = f"https://msedgedriver.microsoft.com/{version}/edgedriver_win64.zip"

        if not os.path.isdir(f"{folder_path}\Selenium"):
            os.mkdir(f"{folder_path}\Selenium")

        if os.path.isdir(f"{folder_path}\Selenium\Driver_Notes"):
            rmtree(f"{folder_path}\Selenium\Driver_Notes")

        if os.path.exists(f"{folder_path}\Selenium\edgedriver_win64.zip"):
            os.remove(f"{folder_path}\Selenium\edgedriver_win64.zip")

        if os.path.exists(f"{folder_path}\Selenium\msedgedriver.exe"):
            os.system("taskkill /F /IM msedgedriver.exe")
            sleep(3)
            os.remove(f"{folder_path}\Selenium\msedgedriver.exe")

        #download(url, rf"{folder_path}\Selenium")
        #download(url, os.path.join(folder_path, "Selenium"))
        helper.download_file(url, os.path.join(folder_path, "Selenium"))
        with ZipFile(f"{folder_path}\Selenium\edgedriver_win64.zip") as zf:
            zf.extractall(path=f"{folder_path}\Selenium")
            zf.close()

    # added by Alvin
    def connect2web(self):
        self.toolButton_connect2web.setEnabled(False)
        self.set_status("Connecting to web...")
        self.browser_request.emit(
            "connect",
            {}
        )

    def document_claim(self):
            self.pushButton_docSubmit.setEnabled(False)
            claim_number = self.lineEdit_claimId.text().replace("-", "").strip()
            contron_number = self.lineEdit_control_docu
            email_preview = self.textEdit_emailPreview.toPlainText().replace("\t", "")
            self.set_status("Searching...")
            self.browser_request.emit(
                "search_claim",
                {
                    "claim": claim_number,
                    "control": contron_number,
                    "email": email_preview
                }
            )

    def connect2web2(self):
        self.toolButton_connect2web.setEnabled(False)

        worker = Worker(self.connect2web_worker)
        worker.signals.finished.connect(
            self.connect_completed
        )
        worker.signals.error.connect(
            self.connect_failed
        )
        self.threadpool.start(worker)

    def connect2web_old(self):
        if not self.is_driver_connected():
            self.driver = None

        documents_folder = os.path.expanduser(f"~\Documents")
        #self.update_edge_browser(folder_path=documents_folder)

        if self.driver is None:
            username = getuser()
            user_data_dir = f'C:\\Users\\{username}\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default'

            service = Service(executable_path=f"{documents_folder}\Selenium\msedgedriver.exe")
            options = webdriver.EdgeOptions()
            options.add_experimental_option("useAutomationExtension", False)
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            options.add_argument(f"user-data-dir={user_data_dir}")

            self.driver = webdriver.Edge(service=service, options=options)
            self.driver.implicitly_wait(15)
            self.driver.maximize_window()
            self.driver.get("https://test-strataware.lmig.com/")

            WebDriverWait(self.driver, 1000).until(EC.title_is('Strataware Web Portal'))
            
            self.open_smartview()
        else:
            self.popup("Browser already initialized. . .")

    def connect2web_worker(self):
        if not self.is_driver_connected():
            self.driver = None

        documents_folder = os.path.expanduser(r"~\Documents")
        #self.update_edge_browser(folder_path=documents_folder)

        if self.driver is None:

            username = getuser()

            user_data_dir = (
                f"C:\\Users\\{username}\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default"
            )

            service = Service(
                executable_path=rf"{documents_folder}\Selenium\msedgedriver.exe"
            )

            options = webdriver.EdgeOptions()
            options.add_experimental_option(
                "useAutomationExtension",
                False
            )
            options.add_experimental_option(
                "excludeSwitches",
                ["enable-automation"]
            )

            options.add_argument(
                f"user-data-dir={user_data_dir}"
            )

            self.driver = webdriver.Edge(
                service=service,
                options=options
            )

            self.driver.implicitly_wait(15)
            self.driver.maximize_window()

            self.driver.get(
                "https://www.selenium.dev"
            )

            WebDriverWait(
                self.driver,
                1000
            ).until(
                EC.title_is("Selenium")
            )

            # Open SmartView
            self.window_focus('Strataware Web Portal')
            sleep(1)
            self.driver.get('https://libertypreview.stratacare.net/strataware/strataware/sview/mainframe.aspx')
            self.wnd1 = self.driver.window_handles[0]
    
            self.driver.switch_to.new_window("tab")
            self.driver.get('https://libertypreview.stratacare.net/strataware/strataware/sview/mainframe.aspx')
            self.wnd2 = self.driver.window_handles[1]
            sleep(1)

            return True

        return False

    def connect_completed(self, result):
        self.toolButton_connect2web.setEnabled(True)

        if result:
            #self.open_smartview()
            self.popup("Connected!")
        else:
            self.popup("Browser already initialized...")

    def connect_failed(self, error):
        self.toolButton_connect2web.setEnabled(True)
        QMessageBox.critical(
            self,
            "Error",
            str(error)
        )
        
    def window_focus(self, win_name):
        is_win_avail = False
        windows = self.driver.window_handles
        for window in windows:
            self.driver.switch_to.window(window)
            if win_name in self.driver.title:
                is_win_avail = True
                break
        sleep(1)
        return is_win_avail

    def open_smartview(self):
        self.window_focus('Strataware Web Portal')
        # self.driver.find_elements(By.TAG_NAME, 'button')[0].click()
        sleep(1)
        # self.driver.find_element(By.XPATH, '(//span[@class="mat-mdc-list-item-unscoped-content mdc-list-item__primary-text"])[5]').click()
        # mat-mdc-list-item-unscoped-content mdc-list-item__primary-text
        # mdc-list-item__content
        self.driver.get('https://libertypreview.stratacare.net/strataware/strataware/sview/mainframe.aspx')
        self.wnd1 = self.driver.window_handles[0]

        self.driver.switch_to.new_window("tab")
        self.driver.get('https://libertypreview.stratacare.net/strataware/strataware/sview/mainframe.aspx')
        self.wnd2 = self.driver.window_handles[1]
        
        sleep(1)

    def document_claim_old(self):
        def page_wait():
            while self.driver.execute_script("javascript: return document.readyState") != "complete":
                sleep(1)
            sleep(1)

        if self.wnd3 == "":
            self.driver.switch_to.new_window("tab")
            self.wnd3 = self.driver.current_window_handle
        else:
            self.driver.switch_to.window(self.wnd3)

        self.driver.get("https://global-claims-notes.lmig.com/notes?segment=WC&wc_clm_id=%s" % self.lineEdit_claimId.text().replace("-", ""))

        wait = WebDriverWait(self.driver, 30)
        wait.until(EC.visibility_of_element_located((By.TAG_NAME, "fluid-theme-provider")))
        page_wait()
        sleep(5)

        try:
            # claim_div = self.gcn_driver.find_element(By.XPATH, "//div[@slot='left-sidebar-content']/div[2]/div[2]").get_attribute("innerText")
            claim_div = self.lineEdit_control_docu.text()
            shadow_host = self.driver.find_element(By.XPATH, "(//fluid-button[@class='hydrated'])[2]")
            shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", shadow_host)
            shadow_btn1 = shadow_root.find_element(By.CSS_SELECTOR, "button")
            wait.until(EC.element_to_be_clickable((shadow_btn1)))
            shadow_btn1.click()

            wait.until(EC.visibility_of_element_located((By.XPATH, "//fluid-combo-box[@class='hydrated']")))
            shadow_host = self.driver.find_element(By.XPATH, "//fluid-combo-box[@class='hydrated']")
            shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", shadow_host)
            shadow_div1 = shadow_root.find_element(By.CSS_SELECTOR, "#undefined-container")
            shadow_div1.click()

            shadow_ulst = shadow_root.find_element(By.CSS_SELECTOR, ".dropdown-menu-list")
            shadow_ulst.find_element(By.CSS_SELECTOR, "#undefinedoption-0").click()

            shadow_host = self.driver.find_element(By.XPATH, "(//fluid-text-area[@class='hydrated'])[1]")
            shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", shadow_host)
            shadow_text = shadow_root.find_element(By.CSS_SELECTOR, ".text-area-input")
            # shadow_text.send_keys(self.text_arr[4])

            shadow_host = self.driver.find_element(By.XPATH, "(//fluid-text-area[@class='hydrated'])[2]")
            shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", shadow_host)
            shadow_text = shadow_root.find_element(By.CSS_SELECTOR, ".text-area-input")
            sleep(3)
            shadow_text.send_keys(self.textEdit_emailPreview.toPlainText().replace("\t", ""))

            self.driver.switch_to.window(self.wnd1)
            self.driver.get('https://libertypreview.stratacare.net/strataware/strataware/sview/mainframe.aspx')
            page_wait()

            self.driver.switch_to.default_content()
            self.driver.switch_to.frame(self.driver.find_element(By.ID, 'applFrame'))
            self.driver.find_element(By.XPATH, "//input[@id='l_ControlNumber']").send_keys(claim_div) # l_ControlNumber
            self.driver.find_element(By.XPATH, "//img[@id='btn_Search']").click()

            self.driver.switch_to.default_content()
            self.driver.switch_to.frame(self.driver.find_element(By.ID, 'applFrame'))
            self.driver.switch_to.frame(self.driver.find_element(By.ID, 'ifmSVSearch'))
            self.driver.find_element(By.CLASS_NAME, "data").click()
            
            # for tr in self.driver.find_elements(By.XPATH, "//table[@id='SCDataGrid']/tbody/tr"):
            #     print(tr.text)
            #     if self.lineEdit_control_docu.text() in tr.text:
            #         tr.click()
            #         break

            sleep(3)
            wait = WebDriverWait(self.driver, 30)
            self.driver.switch_to.default_content()
            self.driver.switch_to.frame(self.driver.find_element(By.ID, 'applFrame'))
            wait.until(EC.visibility_of_element_located((By.XPATH, "//img[@id='imgBillNote']")))
            self.driver.find_element(By.XPATH, "//img[@id='imgBillNote']").click()
            # self.driver.execute_script("showNotes('bill';)")
            sleep(3)
            self.driver.find_element(By.XPATH, "//textarea[@id='taNotes']").send_keys(self.textEdit_emailPreview.toPlainText().replace("\t", ""))

        except Exception as err:
            print(err)
            # self.driver.close()
            return 0
            
    def get_info(self):
        if self.driver.execute_script("javascript: return document.visibilityState") == "hidden":
            if self.driver.current_window_handle == self.wnd1:
                self.driver.switch_to.window(self.wnd2)
            else:
                self.driver.switch_to.window(self.wnd1)

        try:
            self.driver.switch_to.frame('applFrame')
        except:
            self.driver.switch_to.default_content()
            self.driver.switch_to.frame('applFrame')

        claim_number = self.driver.find_element(By.ID, 'lblClaimNumber').get_attribute("innerText")
        self.claim_num = claim_number

        selected_email = self.comboBox_email_templates.currentText()
        preview_body = self.email_body

        ctl_num = self.driver.find_element(By.XPATH, "//label[@id='lblControlNumber']").get_attribute("innerText")
        cli_num = self.driver.find_element(By.XPATH, "//label[@id='lblClientNumber']").get_attribute("innerText")
        tax_id = self.driver.find_element(By.XPATH, "//label[@id='lblTaxID']").get_attribute("innerText")
        prov_name = self.driver.find_element(By.XPATH, "//label[@id='lblProviderName']").get_attribute("innerText")
        prov_state = self.driver.find_element(By.XPATH, "//label[@id='lblVendorState']").get_attribute("innerText")
        clm_state = self.driver.find_element(By.XPATH, "//label[@id='lblClaimState']").get_attribute("innerText")

        self.driver.switch_to.frame('iframeBillData')

        chk_amt = self.driver.find_element(By.XPATH, "//div[@id='divFrameData']/fieldset/table/tbody/tr[18]/td[4]/label").get_attribute("innerText") # Check Amount
        chk_num = self.driver.find_element(By.XPATH, "//div[@id='divFrameData']/fieldset/table/tbody/tr[17]/td[4]/label").get_attribute("innerText") # Check Numbe
        pd_date = self.driver.find_element(By.XPATH, "//div[@id='divFrameData']/fieldset/table/tbody/tr[17]/td[2]/label").get_attribute("innerText") # Paid Date

        self.driver.switch_to.default_content()
        self.driver.switch_to.frame('applFrame')
        self.driver.switch_to.frame('ifmSVSearch')

        tbl = self.driver.find_element(By.XPATH, "//table[@id='SCDataGrid']").find_element(By.TAG_NAME, "tbody")
        for tr in tbl.find_elements(By.XPATH, "./tr"):
            tr_line = tr.get_attribute("innerText")

            if ctl_num in tr_line and cli_num in tr_line and tax_id in tr_line:
                dos_1 = tr.find_element(By.XPATH, "//td[@columnno='13']").get_attribute("innerText")
                dos_2 = tr.find_element(By.XPATH, "//td[@columnno='14']").get_attribute("innerText")
                break

        self.driver.switch_to.default_content()
        
        if "PSU_Refund Request" in selected_email:
            # Claim Number, Control Number, DOS, Check Amount, Doc Number, Bank Code, Check Number
            preview_body = preview_body.replace("WCXXX-XXXXXX", claim_number)
            preview_body = preview_body.replace("CONTROL_NUMBER", ctl_num)
            preview_body = preview_body.replace("XXXXX XXXXXXX XXXXX", prov_name)
            preview_body = preview_body.replace("XX/XX/XXXX", dos_1) if dos_1 == dos_2 else preview_body.replace("XX/XX/XXXX", f"{dos_1}-{dos_2}")
            preview_body = preview_body.replace("chk_amt", chk_amt)
            preview_body = preview_body.replace("chk_num", chk_num)

        elif "PSU_Stop Pay" in selected_email:
            preview_body = preview_body.replace("CLAIM_NUMBER", claim_number)
            preview_body = preview_body.replace("CONTROL_NUMBER", ctl_num)
            preview_body = preview_body.replace("PROVIDER_NAME", prov_name)
            preview_body = preview_body.replace("PROVIDER_STATE", prov_state)
            preview_body = preview_body.replace("DATE_OF_SERVICE", dos_1) if dos_1 == dos_2 else preview_body.replace("DATE_OF_SERVICE", f"{dos_1}-{dos_2}")
            preview_body = preview_body.replace("CHECK_NUMBER", chk_num)
            preview_body = preview_body.replace("PAID_DATE", pd_date)
            preview_body = preview_body.replace("AMOUNT_PAID", chk_amt)

        elif "PSU_Request to Reprocess" in selected_email:
            preview_body = preview_body.replace("WCXXX-XXXXXX", claim_number)
            preview_body = preview_body.replace("CONTROL_NUMBER", ctl_num)
            preview_body = preview_body.replace("XXXXX XXXXXXX XXXXX", prov_name)
            preview_body = preview_body.replace("XX/XX/XXXX", dos_1) if dos_1 == dos_2 else preview_body.replace("XX/XX/XXXX", f"{dos_1}-{dos_2}")

        elif "PSU_Service Transfer" in selected_email:
            preview_body = preview_body.replace("enter claim number ", claim_number)

        elif "PSU_Referral to CS" in selected_email:
            preview_body = preview_body.replace("CLAIM_NUMBER", claim_number)
            preview_body = preview_body.replace("FACILITY_NAME", prov_name)
            preview_body = preview_body.replace("Add CN Here: (To bottom of template)", f"Control #: {ctl_num}")
            preview_body = preview_body.replace("DATE_OF_SERVICE", dos_1) if dos_1 == dos_2 else preview_body.replace("DATE_OF_SERVICE", f"{dos_1}-{dos_2}")

        self.textEdit_preview.setText("")
        self.textEdit_preview.setText(preview_body)
        self.email_body = preview_body
        self.jurisdiction = clm_state


def update_edge_browser():
    folder_path = os.path.expanduser(f"~\Documents")
    fso = Dispatch("Scripting.FileSystemObject")
    version = fso.GetFileVersion("c:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe")
    url = f"https://msedgedriver.microsoft.com/{version}/edgedriver_win64.zip"

    if not os.path.isdir(f"{folder_path}\Selenium"):
        os.mkdir(f"{folder_path}\Selenium")

    if os.path.isdir(f"{folder_path}\Selenium\Driver_Notes"):
        rmtree(f"{folder_path}\Selenium\Driver_Notes")

    if os.path.exists(f"{folder_path}\Selenium\edgedriver_win64.zip"):
        os.remove(f"{folder_path}\Selenium\edgedriver_win64.zip")

    if os.path.exists(f"{folder_path}\Selenium\msedgedriver.exe"):
        os.system("taskkill /F /IM msedgedriver.exe")
        sleep(3)
        os.remove(f"{folder_path}\Selenium\msedgedriver.exe")

    #download(url, rf"{folder_path}\Selenium")
    #download(url, os.path.join(folder_path, "Selenium"))
    helper.download_file(url, os.path.join(folder_path, "Selenium"))
    with ZipFile(f"{folder_path}\Selenium\edgedriver_win64.zip") as zf:
        zf.extractall(path=f"{folder_path}\Selenium")
        zf.close()
        
# Check screen scaling to correct app window scaling since the app window size is locked
# If you can re-scale the widgets properly, you can ditch this
app_scale = ctypes.windll.shcore.GetScaleFactorForDevice(0)
if app_scale <= 125:
    os.environ["QT_SCALE_FACTOR"] = "1"
elif app_scale > 125:
    os.environ["QT_SCALE_FACTOR"] = "0.625"

if hasattr(Qt, 'AA_EnableHighDpiScaling'):
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
if hasattr(Qt, 'AA_UseHighDpiPixmaps'):
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

if __name__ == "__main__":

    #update_edge_browser()

    app = QApplication(argv)
    UIWindow = UI()
    app.exec()