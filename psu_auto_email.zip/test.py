import requests

# url = "https://msedgedriver.microsoft.com/151.0.4129.59/edgedriver_win64.zip"
# r = requests.get(url, verify=False)
# print(r.status_code)

