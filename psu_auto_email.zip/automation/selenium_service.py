from selenium import webdriver
from selenium.webdriver.edge.service import Service
from selenium.webdriver.edge.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep
from getpass import getuser
import os, time
from shutil import rmtree
from win32com.client import Dispatch
import helper
from zipfile import ZipFile


class SeleniumService:

    def __init__(self):

        self.driver = None

        self.wnd1 = None
        self.wnd2 = None
        self.wnd3 = None

    def start_browser(self):

        if self.driver:
            return True

        options = Options()

        options.add_argument("--start-maximized")

        self.driver = webdriver.Edge(
            options=options
        )

        return True

    def close_browser(self):
        try:

            if self.driver:

                self.driver.quit()

        finally:

            self.driver = None
            
    def close(self):

        if self.driver:

            self.driver.quit()
            self.driver = None

    def is_connected(self):

        try:

            if self.driver is None:
                return False

            _ = self.driver.current_url

            return True

        except Exception:

            return False
        
    def connect2web(self):

        if not self.is_connected():
            self.driver = None
        
        documents_folder = os.path.expanduser(r"~\Documents")
        #self.update_edge_browser(folder_path=documents_folder)

        username = getuser()

        user_data_dir = (
            f"C:\\Users\\{username}\\AppData\\Local\\Microsoft\\Edge\\User Data\\Default"
        )

        service = Service(
            executable_path=rf"{documents_folder}\Selenium\msedgedriver.exe"
        )

        options = webdriver.EdgeOptions()

        options.add_experimental_option(
            "useAutomationExtension",
            False
        )
        options.add_experimental_option(
            "excludeSwitches",
            ["enable-automation"]
        )

        options.add_argument(
            f"user-data-dir={user_data_dir}"
        )

        self.driver = webdriver.Edge(
            service=service,
            options=options
        )

        self.driver.implicitly_wait(15)
        self.driver.maximize_window()

        self.initialize_tabs()

        return {
            "success": True,
            "message": "Browser connected"
        }

    def initialize_tabs(self):
        self.driver.get(
            "https://www.selenium.dev"
        )

        WebDriverWait(
            self.driver,
            30
        ).until(
            EC.title_contains("Selenium")
        )

        #
        # Tab 1
        #
        self.driver.get(
            "https://www.google.com/"
        )

        self.wnd1 = self.driver.current_window_handle

        #
        # Tab 2
        #
        self.driver.switch_to.new_window("tab")

        self.driver.get(
            "https://webscraper.io/test-sites"
        )

        self.wnd2 = self.driver.current_window_handle
        
    def document_claim(self, params):

        claim_number = params.get("claim")
        control_number = params.get("control")
        email_preview = params.get("email")

        def page_wait():
            while self.driver.execute_script("javascript: return document.readyState") != "complete":
                    sleep(1)
            sleep(1)
    
        if self.wnd3 == "":
            self.driver.switch_to.new_window("tab")
            self.wnd3 = self.driver.current_window_handle
        else:
            self.driver.switch_to.window(self.wnd3)

        self.driver.get("https://global-claims-notes.lmig.com/notes?segment=WC&wc_clm_id=%s" % claim_number)

        wait = WebDriverWait(self.driver, 30)
        wait.until(EC.visibility_of_element_located((By.TAG_NAME, "fluid-theme-provider")))
        page_wait()
        sleep(5)

        claim_div = control_number
        shadow_host = self.driver.find_element(By.XPATH, "(//fluid-button[@class='hydrated'])[2]")
        shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", shadow_host)
        shadow_btn1 = shadow_root.find_element(By.CSS_SELECTOR, "button")
        wait.until(EC.element_to_be_clickable((shadow_btn1)))
        shadow_btn1.click()

        wait.until(EC.visibility_of_element_located((By.XPATH, "//fluid-combo-box[@class='hydrated']")))
        shadow_host = self.driver.find_element(By.XPATH, "//fluid-combo-box[@class='hydrated']")
        shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", shadow_host)
        shadow_div1 = shadow_root.find_element(By.CSS_SELECTOR, "#undefined-container")
        shadow_div1.click()

        shadow_ulst = shadow_root.find_element(By.CSS_SELECTOR, ".dropdown-menu-list")
        shadow_ulst.find_element(By.CSS_SELECTOR, "#undefinedoption-0").click()

        shadow_host = self.driver.find_element(By.XPATH, "(//fluid-text-area[@class='hydrated'])[1]")
        shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", shadow_host)
        shadow_text = shadow_root.find_element(By.CSS_SELECTOR, ".text-area-input")
        # shadow_text.send_keys(self.text_arr[4])

        shadow_host = self.driver.find_element(By.XPATH, "(//fluid-text-area[@class='hydrated'])[2]")
        shadow_root = self.driver.execute_script("return arguments[0].shadowRoot", shadow_host)
        shadow_text = shadow_root.find_element(By.CSS_SELECTOR, ".text-area-input")
        sleep(3)
        shadow_text.send_keys(email_preview)

        self.driver.switch_to.window(self.wnd1)
        self.driver.get('https://libertypreview.stratacare.net/strataware/strataware/sview/mainframe.aspx')
        page_wait()

        self.driver.switch_to.default_content()
        self.driver.switch_to.frame(self.driver.find_element(By.ID, 'applFrame'))
        self.driver.find_element(By.XPATH, "//input[@id='l_ControlNumber']").send_keys(claim_div) # l_ControlNumber
        self.driver.find_element(By.XPATH, "//img[@id='btn_Search']").click()

        self.driver.switch_to.default_content()
        self.driver.switch_to.frame(self.driver.find_element(By.ID, 'applFrame'))
        self.driver.switch_to.frame(self.driver.find_element(By.ID, 'ifmSVSearch'))
        self.driver.find_element(By.CLASS_NAME, "data").click()
        
        sleep(3)
        wait = WebDriverWait(self.driver, 30)
        self.driver.switch_to.default_content()
        self.driver.switch_to.frame(self.driver.find_element(By.ID, 'applFrame'))
        wait.until(EC.visibility_of_element_located((By.XPATH, "//img[@id='imgBillNote']")))
        self.driver.find_element(By.XPATH, "//img[@id='imgBillNote']").click()
        # self.driver.execute_script("showNotes('bill';)")
        sleep(3)
        self.driver.find_element(By.XPATH, "//textarea[@id='taNotes']").send_keys(email_preview)

        return {
            "claim": claim_number,
            "status": "Completed"
        }