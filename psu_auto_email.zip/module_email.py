import os, extract_msg, win32com.client as win32
import ctypes

def get_display_name():
    GetUserNameEx = ctypes.windll.secur32.GetUserNameExW
    NameDisplay = 3

    size = ctypes.pointer(ctypes.c_ulong(0))
    GetUserNameEx(NameDisplay, None, size)

    nameBuffer = ctypes.create_unicode_buffer(size.contents.value)
    GetUserNameEx(NameDisplay, nameBuffer, size)
    return nameBuffer.value

def email_templates():
    filenames = []
    filenames.append('')
    for filename in os.listdir('template'):
        if os.path.isfile(os.path.join('template', filename)):
            filenames.append(os.path.splitext(filename)[0])
    return filenames

def email_content(filename):
    path = f'template/{filename}.msg'
    msg = extract_msg.openMsg(path)
    body = msg.htmlBody
    recip = msg.to
    cc = msg.cc
    subject = msg.subject

    return body, recip, cc, subject

def create_email(args):
    # args: [0] Template Title, [1] Email Body, [2] Email Recipients, [3] Email CC
    # [4] Email Subject, [5] Jurisdiction, [6] Claim Number, [7] Jurisdiction
    
    # path = f'template/{args[0]}.msg'
    # msg = extract_msg.Message(path)

    # Read the HTML body of the message
    html_body = args[1]

    # Decode the HTML body if it's in bytes
    if isinstance(html_body, bytes):
        html_body = html_body.decode('utf-8')

    # Create a new Outlook email
    outlook = win32.Dispatch('outlook.application')
    mail = outlook.CreateItem(0)
    mail.HTMLBody = html_body
    mail.to = args[2]
    mail.cc = args[3]
    mail.recipients.resolveAll

    if "PSU_Refund Request" in args[4]: 
        mail.subject = args[4].replace("Claim #", args[6]).replace("EnterJurisdiction", args[5])
    elif "PSU_Referral to CS" in args[4]: 
        mail.subject = args[4].replace("Claim #", args[6]).replace("EnterJurisdiction", args[5])
    elif "PSU_Request to Reprocess" in args[4]: 
        mail.subject = args[4].replace("ClaimNumber", args[6]).replace("EnterJurisdiction", args[5])
    elif "PSU_Service Transfer" in args[4]: 
        mail.subject = args[4].replace("claim number", args[6]).replace("processor name / ", "").replace("EnterJurisdiction", args[5])
    elif "PSU_Stop Pay - Reissue" in args[4]:
        mail.subject = args[4].replace("Claim #", args[6]).replace("EnterJurisdiction", args[5])

    # Display the email
    mail.Display()
    